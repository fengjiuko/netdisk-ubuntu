# 文件/文件夹操作API
[详细介绍](./ifilefolder.h) <br>
[<--](../README.md)
