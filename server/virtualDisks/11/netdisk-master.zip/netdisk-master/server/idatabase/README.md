# 数据库交互接口
[详细介绍](./idatabase.h) <br>
[<--](../README.md)