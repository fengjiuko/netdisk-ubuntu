## Netdisk

### 概述
* [通信数据单元内容规范](msgUnit.md)
* [服务器](server/README.md)
* [客户端](client/README.md)

### 运行截图
![登陆页](./DemoImages/loginpage.png)
![文件管理页](./DemoImages/filefolderpage.png)
![文件传输页](./DemoImages/transmitpage.png)
![好友页](./DemoImages/friendpage.png)
![设置页](./DemoImages/settingpage.png)